//igor guilherme pereira loredo
// nusp 11275071

usou um makefile para compilar e rodar, basta digitar "make && make run" 
no terminal na pasta que ja roda e compila o programa.
